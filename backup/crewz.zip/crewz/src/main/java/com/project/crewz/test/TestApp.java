package com.project.crewz.test;

import com.project.crewz.category.Category;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.ArrayList;
import java.util.Date;

@Controller
public class TestApp {
    @RequestMapping("/")
    public String home(Model m) {
        ArrayList<Category> list = new ArrayList<>();
        // no, name, photo, total
        list.add(new Category(1, "독서", null, 10));
        list.add(new Category(2, "운동", null, 1));
        list.add(new Category(3, "요리", null, 90));
        list.add(new Category(4, "재테크", null, 15));
        list.add(new Category(5, "전자기기", null, 30));

        m.addAttribute("catlist", list);
        m.addAttribute("log", true);

        return "index";
    }

    @RequestMapping("/search/{category}")
    public String cat(Model model, @PathVariable("category") String category) {
        ArrayList<Msg> list = new ArrayList<>();
        list.add(new Msg("Hello1", "World1", new Date()));
        list.add(new Msg("Hello2", "World2", new Date()));
        list.add(new Msg("Hello3", "World3", new Date()));
        list.add(new Msg("Hello4", "World4", new Date()));
        list.add(new Msg("Hello5", "World5", new Date()));
        list.add(new Msg("Hello6", "World6", new Date()));

        model.addAttribute("log", true);
        model.addAttribute("list", list);
        model.addAttribute("category", category);

        return "search";
    }

    @RequestMapping("/search/{category}/keyword")
    public String search(Model model, @PathVariable("category") String category, String msg) {
        ArrayList<Msg> list = new ArrayList<>();
        list.add(new Msg("Search1", "Search World1", new Date()));
        list.add(new Msg("Search2", "Search World2", new Date()));
        list.add(new Msg("Search3", "Search World3", new Date()));
        list.add(new Msg("Search4", "Search World4", new Date()));
        list.add(new Msg("Search5", "Search World5", new Date()));
        list.add(new Msg("Search6", "Search World6", new Date()));

        model.addAttribute("log", true);
        model.addAttribute("list", list);
        model.addAttribute("category", category);
        model.addAttribute("msg", msg);

        return "search";
    }

    @RequestMapping("/category/{no}/view")
    public String info(@PathVariable("no") int no, int num, Model model) {
        model.addAttribute("log", false);
        return "moim";
    }

    @RequestMapping("/myinfo/{name}")
    public String mypage(@PathVariable("name") String name) {
        return "mypage/myinfo";
    }

//    @RequestMapping("/category/{no1}/view/{no2}/review")
//    public String review(@PathVariable("no1") int no1, @PathVariable("no2") int no2, int no) {
//        return "review";
//    }
}
