package com.project.crewz.somoim;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Somoimsub {
    private int somoimno;
    private String memberid;
    private int partin;
}
