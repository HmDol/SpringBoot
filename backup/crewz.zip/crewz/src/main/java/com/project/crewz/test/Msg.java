package com.project.crewz.test;

import lombok.*;

import java.util.Date;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Msg {
    private String title;
    private String content;
    private Date date;
}
