package com.project.crewz.moim;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Moimlike {
    private int moimno;
    private String memberid;
    private int love;
}