package com.project.crewz.test;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@RestController
@CrossOrigin("*")
public class RestTest {
    @GetMapping("/moiminfo")
    public Map get(int no) {
        Map map = new HashMap();

        map.put("moim-name", "Moim");
        map.put("moim-content", "Moim-Content");

        return map;
    }

    @GetMapping("/msg")
    public Map getMsg(int no) {
        Map map = new HashMap();

        ArrayList<Msg> list = new ArrayList<>();
        if(no == 0) {
            list.add(new Msg("Rest1", "Rest World1", new Date()));
            list.add(new Msg("Rest2", "Rest World2", new Date()));
            list.add(new Msg("Rest3", "Rest World3", new Date()));
            list.add(new Msg("Rest4", "Rest World4", new Date()));
            list.add(new Msg("Rest5", "Rest World5", new Date()));
        } else {
            list.add(new Msg("Rest1-1", "Rest World1", new Date()));
            list.add(new Msg("Rest2-1", "Rest World2", new Date()));
            list.add(new Msg("Rest3-3", "Rest World3", new Date()));
            list.add(new Msg("Rest4-1", "Rest World4", new Date()));
            list.add(new Msg("Rest5-1", "Rest World5", new Date()));
        }

        map.put("msglist", list);

        return map;
    }
}
