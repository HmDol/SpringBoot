package com.project.crewz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrewzApplicationTests {

    @Test
    void contextLoads() {
    }

}
